from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

# 1. '요일'을 저장할 새 모델 (월, 화, 수...)
class Day(models.Model):
    name = models.CharField(max_length=10) # 예: '월요일'
    slug = models.CharField(max_length=3)  # 예: 'mon'

    def __str__(self):
        return self.name

class StudyGroup(models.Model):
    TYPE_CHOICES = [
        ('online', '온라인'),
        ('offline', '오프라인'),
        ('both', '온/오프라인'),
    ]
    # DAY_CHOICES 삭제
    TIME_CHOICES = [
        ('morning', '오전'),
        ('afternoon', '오후'),
        ('evening', '저녁'),
    ]
    
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    leader = models.ForeignKey(User, on_delete=models.CASCADE, related_name='led_studies')
    members = models.ManyToManyField(User, related_name='joined_studies', blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    study_type = models.CharField(max_length=10, choices=TYPE_CHOICES, blank=True, null=True)
    
    # 2. 'study_day' (하나만 선택) 필드 삭제
    
    # 3. 'study_days' (여러 개 선택) 필드 추가
    study_days = models.ManyToManyField(Day, blank=True)
    
    study_time = models.CharField(max_length=10, choices=TIME_CHOICES, blank=True, null=True)

    def __str__(self):
        return self.name

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    certificates = models.TextField(blank=True, null=True)
    career = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.user.username

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    try:
        instance.profile.save()
    except Profile.DoesNotExist:
        Profile.objects.create(user=instance)

class Post(models.Model):
    BOARD_CHOICES = [
        ('notice', '공지사항'),
        ('archive', '자료실'),
        ('free', '자유게시판'),
    ]
    
    study_group = models.ForeignKey(StudyGroup, on_delete=models.CASCADE, related_name='posts')
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    content = models.TextField()
    
    attachment = models.FileField(upload_to='posts/', blank=True, null=True)
    board_type = models.CharField(max_length=10, choices=BOARD_CHOICES, default='free')
    created_at = models.DateTimeField(auto_now_add=True)
    
    def get_filename(self):
        return self.attachment.name.split('/')[-1] if self.attachment else None
    def __str__(self):
        return f'[{self.study_group.name} / {self.get_board_type_display()}] {self.title}'

class Event(models.Model):
    study_group = models.ForeignKey(StudyGroup, on_delete=models.CASCADE, related_name='events')
    author = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    title = models.CharField(max_length=200)
    date = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f'[{self.study_group.name}] {self.date}: {self.title}'

class Comment(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='comments')
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    parent = models.ForeignKey('self', null=True, blank=True, on_delete=models.CASCADE, related_name='replies')
    def __str__(self):
        return f'Comment by {self.author} on {self.post}'