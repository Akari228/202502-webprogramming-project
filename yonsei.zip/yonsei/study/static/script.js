document.addEventListener('DOMContentLoaded', () => {

    const leaveButtons = document.querySelectorAll('.leave-btn');
    leaveButtons.forEach(button => {
        button.addEventListener('click', () => {
            if (confirm('정말 이 스터디에서 탈퇴하시겠습니까?')) {
            }
        });
    });

    const newPostButtons = document.querySelectorAll('.new-post-btn');
    newPostButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            window.location.href = button.href;
        });
    });

    const postForm = document.getElementById('post-form');
    if (postForm) {
        postForm.addEventListener('submit', (event) => {
            
            const title = document.getElementById('post-title').value;
            const content = document.getElementById('post-content').value;

            if (!title.trim() || !content.trim()) {
                event.preventDefault(); 
                alert('제목과 내용을 모두 입력해주세요.');
                return;
            }
        });
    }

});

function showClickedSchedule(dayElement) {
    
    const dayString = dayElement.getAttribute('data-day');
    
    // ▼▼▼ [추가] 이 코드를 추가하여 "NaN" 오류를 원천 차단합니다.
    if (!dayString || !dayString.includes('-')) {
        console.error("Invalid data-day attribute:", dayString);
        return; // "YYYY-MM-DD" 형식이 아니면 함수 종료
    }
    // ▲▲▲ [추가] 

    const displayHeader = document.getElementById('schedule-display-header');
    // ... (이하 코드는 동일) ...
    const scheduleItemsContainer = document.getElementById('schedule-items');
    
    const events = EVENTS_DATA[dayString];

    const parts = dayString.split('-');
    const year = parts[0];
    const month = parseInt(parts[1], 10);
    const day = parseInt(parts[2], 10);

    displayHeader.textContent = `${year}년 ${month}월 ${day}일의 일정`;
    
    scheduleItemsContainer.innerHTML = '';
    
    // --- (이하 코드는 거의 동일) ---

    scheduleItemsContainer.innerHTML = ''; 

    const allDates = document.querySelectorAll('.calendar-dates span');
    allDates.forEach(d => d.classList.remove('selected'));
    dayElement.classList.add('selected');

    // 5. [수정됨] 이벤트 목록 순회 로직 변경
    if (events && events.length > 0) {
        
        // events는 이제 [{title: "일정1"}, {title: "일정2"}] 형태의 '객체 배열'입니다.
        // 따라서 'eventTitle'이 아닌 'event' 객체로 받고, 'event.title'로 접근해야 합니다.
        events.forEach(event => { 
            scheduleItemsContainer.innerHTML += `<div class="schedule-item">${event.title}</div>`;
        });
        
    } else {
        scheduleItemsContainer.innerHTML = `<div class="no-schedule">예정된 일정이 없습니다.</div>`;
    }
}