from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib import messages 
from .models import StudyGroup, Post, Event, Profile, Day
from django.contrib.auth.decorators import login_required
import datetime
import json
from calendar import Calendar

@login_required 
def index_view(request):
    studies = StudyGroup.objects.all() 
    context = {
        'studies': studies
    }
    return render(request, 'index.html', context)

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user) 
            return redirect('index') 
        else:
            messages.error(request, '아이디 또는 비밀번호가 올바르지 않습니다.')
            return redirect('login')
            
    else:
        return render(request, 'login.html')

def signup_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        first_name = request.POST.get('first_name')
        email = request.POST.get('email')
        password = request.POST.get('password')
        password_confirm = request.POST.get('password-confirm')
        
        if not first_name:
            messages.error(request, '이름을 입력해주세요.')
            return redirect('signup')

        if password != password_confirm:
            messages.error(request, '비밀번호가 일치하지 않습니다.')
            return redirect('signup')
        
        if User.objects.filter(username=username).exists():
            messages.error(request, '이미 사용 중인 아이디입니다.')
            return redirect('signup')
        
        user = User.objects.create_user(
            username=username,
            email=email,
            password=password,
            first_name=first_name
        )
        
        messages.success(request, '회원가입이 완료되었습니다! 로그인해주세요.')
        return redirect('login') 

    else:
        return render(request, 'signup.html')

def logout_view(request):
    logout(request) 
    return redirect('login')

@login_required
def search_view(request):
    query = request.GET.get('q')
    day_ids = request.GET.getlist('day')
    time = request.GET.get('time')
    study_type = request.GET.get('type')

    studies = StudyGroup.objects.all()
    
    if query:
        studies = studies.filter(name__icontains=query)
    
    if day_ids:
        studies = studies.filter(study_days__id__in=day_ids).distinct()
    
    if time:
        studies = studies.filter(study_time=time)
        
    if study_type:
        studies = studies.filter(study_type=study_type)
    
    context = {
        'query': query,
        'day_ids': day_ids,
        'time': time,
        'type': study_type,
        'studies': studies,
        'days_list': Day.objects.all(),
    }
    return render(request, 'search.html', context)

@login_required
def create_study_view(request):
    if request.method == 'POST':
        name = request.POST.get('group_name')
        description = request.POST.get('group_desc')
        study_type = request.POST.get('study_type')
        study_day_ids = request.POST.getlist('study_days')
        study_time = request.POST.get('study_time')
        
        if not name:
            messages.error(request, '그룹 이름은 필수입니다.')
            return redirect('create_study')
        
        group = StudyGroup.objects.create(
            name=name,
            description=description,
            leader=request.user,
            study_type=study_type if study_type else None,
            study_time=study_time if study_time else None
        )
        
        group.study_days.set(study_day_ids)
        group.members.add(request.user)
        
        messages.success(request, '스터디 그룹이 성공적으로 생성되었습니다!')
        
        return redirect('index')
        
    else:
        context = {
            'days': Day.objects.all()
        }
        return render(request, 'create.html', context)

@login_required
def study_detail_view(request, study_id):
    group = get_object_or_404(StudyGroup, id=study_id)
    
    if request.method == 'POST':
        group.members.add(request.user)
        messages.success(request, f"'{group.name}' 스터디에 참여했습니다!")
        return redirect('study_joined', study_id=group.id)
    
    else:
        context = {
            'group': group
        }
        return render(request, 'study-detail.html', context)

@login_required
def my_studies_view(request):
    if request.method == 'POST':
        group_id = request.POST.get('group_id')
        action = request.POST.get('action')
        
        if action == 'leave' and group_id:
            group = get_object_or_404(StudyGroup, id=group_id)
            
            if group.leader == request.user:
                messages.error(request, f"리더는 '{group.name}' 스터디를 탈퇴할 수 없습니다.")
            elif request.user in group.members.all():
                group.members.remove(request.user)
                
                group.refresh_from_db()
                if request.user not in group.members.all():
                    messages.success(request, f"'{group.name}' 스터디에서 탈퇴했습니다.")
                else:
                    messages.error(request, "알 수 없는 오류로 탈퇴에 실패했거나, 이미 탈퇴한 스터디입니다.") 
            
            return redirect('my_studies')
            
    studies = request.user.joined_studies.all()
    context = {
        'studies': studies
    }
    return render(request, 'my-studies.html', context)

@login_required
def leave_study_view(request, study_id):
    group = get_object_or_404(StudyGroup, id=study_id)
    
    if request.method == 'POST':
        group.members.remove(request.user)
        messages.success(request, f"'{group.name}' 스터디에서 탈퇴했습니다.")
        return redirect('my_studies')
    else:
        return redirect('my_studies')

@login_required
def study_joined_view(request, study_id):
    group = get_object_or_404(StudyGroup, id=study_id)
    
    if request.method == 'POST':
        title = request.POST.get('event_title')
        date = request.POST.get('event_date')
        
        if title and date:
            Event.objects.create(
                study_group=group,
                title=title,
                date=date
            )
            messages.success(request, '일정이 추가되었습니다.')
        else:
            messages.error(request, '일정 내용과 날짜를 모두 입력해주세요.')
        
        return redirect('study_joined', study_id=group.id)

    else:
        today = datetime.date.today()
        year_str = request.GET.get('year', str(today.year))
        month_str = request.GET.get('month', str(today.month))
        year = int(year_str)
        month = int(month_str)
        
        current_month_date = datetime.date(year, month, 1)
        
        prev_month_date = (current_month_date - datetime.timedelta(days=1)).replace(day=1)
        next_month_date = (current_month_date + datetime.timedelta(days=31)).replace(day=1)

        cal = Calendar(firstweekday=6)
        calendar_weeks = cal.monthdatescalendar(year, month)
        
        start_date = calendar_weeks[0][0]
        end_date = calendar_weeks[-1][-1]

        events_in_view = Event.objects.filter(
            study_group=group,
            date__gte=start_date, # 시작 날짜(10/26)부터
            date__lte=end_date    # 끝 날짜(12/6)까지
        )
        
        events_dict_by_date = {}
        for event in events_in_view:
            day_key = event.date.strftime('%Y-%m-%d') # "2025-11-26" 형식
            
            if day_key not in events_dict_by_date:
                events_dict_by_date[day_key] = []
            

            events_dict_by_date[day_key].append({
                'title': event.title,
            })


        events_json_str = json.dumps(events_dict_by_date)
        

        notice_posts = Post.objects.filter(study_group=group, board_type='notice').order_by('-created_at')
        archive_posts = Post.objects.filter(study_group=group, board_type='archive').order_by('-created_at')
        free_posts = Post.objects.filter(study_group=group, board_type='free').order_by('-created_at')
        
        context = {
            'group': group,
            'notice_posts': notice_posts,
            'archive_posts': archive_posts,
            'free_posts': free_posts,
            'calendar_weeks': calendar_weeks,
            'current_month': current_month_date,
            'today': today,
            'prev_month_url': f"?year={prev_month_date.year}&month={prev_month_date.month}",
            'next_month_url': f"?year={next_month_date.year}&month={next_month_date.month}",
            
            # 7. 'events_dict' 대신 새로 만든 두 변수를 context에 전달합니다.
            'events_py_dict': events_dict_by_date,   # (HTML의 'has-event' 클래스 확인용)
            'events_json_str': events_json_str,      # (JavaScript의 'EVENTS_DATA' 변수용)
        }
        return render(request, 'study-joined.html', context)

@login_required
def create_post_view(request, study_id):
    group = get_object_or_404(StudyGroup, id=study_id)
    
    if request.method == 'POST':
        title = request.POST.get('post-title')
        content = request.POST.get('post-content')
        board_type = request.POST.get('board-type')
        
        if not title or not content:
            messages.error(request, '제목과 내용을 모두 입력해주세요.')
            return redirect('create_post', study_id=group.id) 
        
        Post.objects.create(
            study_group=group,
            author=request.user,
            title=title,
            content=content,
            board_type=board_type
        )
        
        messages.success(request, '새 글이 등록되었습니다.')
        return redirect('study_joined', study_id=group.id)

    else:
        context = {
            'group': group
        }
        return render(request, 'create-post.html', context)

@login_required
def edit_profile_view(request):
    try:
        profile = request.user.profile
    except Profile.DoesNotExist:
        profile = Profile.objects.create(user=request.user)

    if request.method == 'POST':
        certificates = request.POST.get('certificates')
        career = request.POST.get('career')
        
        profile.certificates = certificates
        profile.career = career
        profile.save()
        
        messages.success(request, '프로필이 성공적으로 업데이트되었습니다.')
        return redirect('edit_profile')
    
    else:
        return render(request, 'edit-profile.html')