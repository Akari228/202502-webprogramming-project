from django.urls import path
from . import views

urlpatterns = [
    # / (기본 주소, 로그인)
    path('', views.login_view, name='login'), 
    
    # /index/ (홈)
    path('index/', views.index_view, name='index'),
    
    # /signup/ (회원가입)
    path('signup/', views.signup_view, name='signup'),
    
    # /logout/ (로그아웃)
    path('logout/', views.logout_view, name='logout'), 
    
    # /edit-profile/ (내 정보 수정)
    path('edit-profile/', views.edit_profile_view, name='edit_profile'),
    
    # /search/ (검색)
    path('search/', views.search_view, name='search'),
    
    # /create-study/ (스터디 그룹 생성)
    path('create-study/', views.create_study_view, name='create_study'),
    
    # /study/<int:study_id>/ (스터디 참여 전 상세)
    path('study/<int:study_id>/', views.study_detail_view, name='study_detail'),
    
    # /my-studies/ (내 스터디 목록)
    path('my-studies/', views.my_studies_view, name='my_studies'),
    
    # /leave-study/<int:study_id>/ (스터디 탈퇴)
    path('leave-study/<int:study_id>/', views.leave_study_view, name='leave_study'),
    
    # /study-joined/<int:study_id>/ (참여 후 스터디 상세/게시판)
    path('study-joined/<int:study_id>/', views.study_joined_view, name='study_joined'),
    
    # /study-joined/<int:study_id>/create-post/ (게시판 글쓰기)
    path('study-joined/<int:study_id>/create-post/', views.create_post_view, name='create_post'),

    # /study/<int:study_id>/edit/ (스터디 수정)
    path('study/<int:study_id>/edit/', views.edit_study_view, name='edit_study'),

    # 게시글 상세 및 댓글 관련 URL
    path('study-joined/<int:study_id>/post/<int:post_id>/', views.post_detail_view, name='post_detail'),
    path('study-joined/<int:study_id>/post/<int:post_id>/comment/<int:comment_id>/delete/', views.delete_comment_view, name='delete_comment'),
    path('study-joined/<int:study_id>/post/<int:post_id>/comment/<int:comment_id>/edit/', views.edit_comment_view, name='edit_comment'),
    path('study-joined/<int:study_id>/event/<int:event_id>/delete/', views.delete_event_view, name='delete_event'),
    path('study-joined/<int:study_id>/event/<int:event_id>/edit/', views.edit_event_view, name='edit_event'),
    path('study-joined/<int:study_id>/post/<int:post_id>/edit/', views.edit_post_view, name='edit_post'),
    path('study-joined/<int:study_id>/post/<int:post_id>/delete/', views.delete_post_view, name='delete_post'),
]