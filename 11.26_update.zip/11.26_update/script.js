document.addEventListener('DOMContentLoaded', () => {

    const leaveButtons = document.querySelectorAll('.leave-btn');
    leaveButtons.forEach(button => {
        button.addEventListener('click', () => {
            if (confirm('정말 이 스터디에서 탈퇴하시겠습니까?')) {
            }
        });
    });

    const newPostButtons = document.querySelectorAll('.new-post-btn');
    newPostButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            window.location.href = button.href;
        });
    });

    const postForm = document.getElementById('post-form');
    if (postForm) {
        postForm.addEventListener('submit', (event) => {
            
            const title = document.getElementById('post-title').value;
            const content = document.getElementById('post-content').value;

            if (!title.trim() || !content.trim()) {
                event.preventDefault(); 
                alert('제목과 내용을 모두 입력해주세요.');
                return;
            }
        });
    }

});

function showClickedSchedule(dayElement) {
    
    const dayString = dayElement.getAttribute('data-day');
    
    if (!dayString || !dayString.includes('-')) {
        console.error("Invalid data-day attribute:", dayString);
        return; // "YYYY-MM-DD" 형식이 아니면 함수 종료
    }

    const displayHeader = document.getElementById('schedule-display-header');

    const scheduleItemsContainer = document.getElementById('schedule-items');
    
    const events = EVENTS_DATA[dayString];

    const parts = dayString.split('-');
    const year = parts[0];
    const month = parseInt(parts[1], 10);
    const day = parseInt(parts[2], 10);

    displayHeader.textContent = `${year}년 ${month}월 ${day}일의 일정`;
    
    scheduleItemsContainer.innerHTML = '';

    scheduleItemsContainer.innerHTML = ''; 

    const allDates = document.querySelectorAll('.calendar-dates span');
    allDates.forEach(d => d.classList.remove('selected'));
    dayElement.classList.add('selected');

    if (events && events.length > 0) {
        

        const pathParts = window.location.pathname.split('/');
        const studyId = pathParts[2]; 

        const csrfTokenValue = document.querySelector('[name=csrfmiddlewaretoken]').value;

        events.forEach(event => { 
            // 1. 전체를 감싸는 div
            const itemDiv = document.createElement('div');
            itemDiv.className = 'schedule-item';
            // 스타일을 보기 좋게 정리 (CSS 파일로 옮겨도 됩니다)
            itemDiv.style.display = 'flex';
            itemDiv.style.justifyContent = 'space-between';
            itemDiv.style.alignItems = 'center';
            itemDiv.style.borderBottom = '1px solid #eee';
            itemDiv.style.padding = '8px 0';

            // 2. 일정 제목
            const titleSpan = document.createElement('span');
            titleSpan.textContent = "• " + event.title;

            // 3. 버튼 그룹 (수정/삭제)
            const btnGroup = document.createElement('div');
            btnGroup.style.display = 'flex';
            btnGroup.style.gap = '8px';
            btnGroup.style.alignItems = 'center';

            // (1) 수정 버튼 (링크)
            const editLink = document.createElement('a');
            editLink.href = `/study-joined/${studyId}/event/${event.id}/edit/`;
            editLink.textContent = '수정';
            editLink.style.fontSize = '12px';
            editLink.style.color = '#1e88e5';
            editLink.style.textDecoration = 'none';

            // (2) 삭제 버튼 (폼 제출 방식)
            const deleteForm = document.createElement('form');
            deleteForm.method = 'POST';
            deleteForm.action = `/study-joined/${studyId}/event/${event.id}/delete/`;
            deleteForm.style.margin = '0';

            // CSRF 토큰 input 추가
            const csrfInput = document.createElement('input');
            csrfInput.type = 'hidden';
            csrfInput.name = 'csrfmiddlewaretoken';
            csrfInput.value = csrfTokenValue;

            const deleteBtn = document.createElement('button');
            deleteBtn.type = 'submit';
            deleteBtn.textContent = '삭제';
            deleteBtn.style.fontSize = '12px';
            deleteBtn.style.color = '#e74c3c';
            deleteBtn.style.border = 'none';
            deleteBtn.style.background = 'none';
            deleteBtn.style.cursor = 'pointer';
            deleteBtn.onclick = function() { return confirm('정말 삭제하시겠습니까?'); };

            deleteForm.appendChild(csrfInput);
            deleteForm.appendChild(deleteBtn);

            btnGroup.appendChild(editLink);
            btnGroup.appendChild(deleteForm);

            itemDiv.appendChild(titleSpan);
            itemDiv.appendChild(btnGroup);

            scheduleItemsContainer.appendChild(itemDiv);
        });
        
    } else {
        scheduleItemsContainer.innerHTML = `<div class="no-schedule">예정된 일정이 없습니다.</div>`;
    }
}