from django.contrib import admin
from .models import StudyGroup, Post, Event, Profile, Day, Comment

class StudyGroupAdmin(admin.ModelAdmin):
    filter_horizontal = ('members', 'study_days',)

class PostAdmin(admin.ModelAdmin):
    list_display = ('title', 'study_group', 'author', 'board_type', 'created_at')
    list_filter = ('board_type', 'study_group')

class EventAdmin(admin.ModelAdmin):
    list_display = ('title', 'study_group', 'date')
    list_filter = ('study_group', 'date')

class CommentAdmin(admin.ModelAdmin):
    list_display = ('content', 'author', 'post', 'created_at')
    list_filter = ('created_at', 'author')

admin.site.register(Day)
admin.site.register(StudyGroup, StudyGroupAdmin)
admin.site.register(Post, PostAdmin)
admin.site.register(Event, EventAdmin)
admin.site.register(Profile)
admin.site.register(Comment, CommentAdmin)